package SystemLab;

import _6_Sorting._0_Java_Inbuilt_Sorting;
import com.sun.jdi.event.ThreadStartEvent;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.concurrent.Semaphore;

public class Assignment_1_Problem_2 {
    public static void main(String[] args) throws InterruptedException {
        ArrayList<Process> list=new ArrayList<>();
        Semaphore queueMutex=new Semaphore(1);
        Semaphore mutex=new Semaphore(1);
        Semaphore writerLock=new Semaphore(1);
        for (int i=0;i<10;i++)
        {
            list.add(new Process(100+i,queueMutex,mutex,writerLock,"Guest"+i));
            list.get(i).start();
        }
        Scheduler scheduler=new Scheduler(queueMutex,mutex,writerLock,"Scheduler");
        scheduler.start();
    }
}
class myComparator implements Comparator<Request>
{
    @Override
    public int compare(Request p1, Request p2) {
        return p1.p.id-p2.p.id;
    }
}
class SharedQueue{
    static PriorityQueue<Request> pq=new PriorityQueue<>(10,new myComparator());
}
class SharedCounter{
    static int readCount=0;
}
class Request{
    int type;
    Process p;
    int burstTime;
    Request(int type, Process p)
    {
        this.type=type;
        this.p=p;
        this.burstTime=((int)(Math.random()*100));

    }
}
class Process extends  Thread{
    Semaphore queueMutex;
    Semaphore mutex;
    Semaphore writerLock;
    int id;
    public Process(int id,Semaphore queueMutex,Semaphore mutex,Semaphore writerLock, String threadName)
    {
        super(threadName);
        this.id=id;
        this.queueMutex=queueMutex;
        this.mutex=mutex;
        this.writerLock=writerLock;
    }

    @Override
    public void run()
    {
        try {
            Request request = new Request(0, this);
            queueMutex.acquire();
            SharedQueue.pq.add(request);
            queueMutex.release();
            this.suspend();
            read(request, id);

            request=new Request(1,this);
            queueMutex.acquire();
            SharedQueue.pq.add(request);
            queueMutex.release();
            this.suspend();
            write(request,id);
    } catch (InterruptedException e) {
        e.printStackTrace();
    }


    }
    public void read(Request request,int  ProcessId)
    {
        try {
        mutex.acquire();
        SharedCounter.readCount++;
        if (SharedCounter.readCount==1)
            writerLock.acquire();
        mutex.release();
        System.out.println("Guest "+ProcessId +" Performing read operation");
        String message=WeddingCard.greetings;
        Thread.sleep(request.burstTime);
        System.out.println("Guest "+ProcessId +" finished read operation");
        mutex.acquire();
        SharedCounter.readCount--;

            if (SharedCounter.readCount==0)
        {
            writerLock.release();
        }
        mutex.release();

        }catch (InterruptedException e) {
        e.printStackTrace();
    }

    }
    public void write(Request request,int ProcessId)
    {
        try {

            writerLock.acquire();
            System.out.println("Guest "+ProcessId +" Performing write operation" + writerLock.availablePermits());
            writerLock.release();
            System.out.println("Guest "+ProcessId +" finished write operation"+ writerLock.availablePermits());
        }catch (InterruptedException e) {
            e.printStackTrace();
        }
    }


}
class Scheduler extends Thread{
    Semaphore queueMutex;
    Semaphore mutex;
    Semaphore writerLock;
    public Scheduler(Semaphore queueMutex,Semaphore mutex,Semaphore writerLock, String threadName)
    {
        super(threadName);
        this.queueMutex=queueMutex;
        this.mutex=mutex;
        this.writerLock=writerLock;
    }
    @Override
    public void run()
    { try {
        int count=0;
        while (count++<1000)
        {

            Request request;
            queueMutex.acquire();

            Thread.sleep(100);
            if (!SharedQueue.pq.isEmpty()) {
                request = SharedQueue.pq.poll();
                request.p.resume();
                queueMutex.release();

            }
            else
            {
                queueMutex.release();
            }
        }


    }catch (InterruptedException e) {
        e.printStackTrace();
    }
    }


}
class WeddingCard{
    static String greetings="";
    static int readCount=0;
}

