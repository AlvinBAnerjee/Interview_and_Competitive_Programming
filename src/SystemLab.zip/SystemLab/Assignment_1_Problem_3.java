package SystemLab;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Scanner;
import java.util.concurrent.Semaphore;

public class Assignment_1_Problem_3 {

    public static void main(String[] args) throws InterruptedException, FileNotFoundException {
        performRead();
        Shared.safeSeqPossible(Shared.processes, Shared.avail, Shared.maxm, Shared.allot);
        Semaphore sem=new Semaphore(1);
        for (int i=1;i<=Shared.processes.length;i++)
        {
            Process p =new Process(i,sem);
            p.start();
        }
        Thread.sleep(1000);
        System.out.println("All Process Ended!");

    }
    static void performRead() throws InterruptedException, FileNotFoundException {
        System.out.print("Reading Files");
        for (int i=0;i<10;i++) {
            Thread.sleep(100);
            System.out.print(".");
        }
        File text = new File("src/SystemLab/input.txt");
        Scanner sc=new Scanner(text);
        int n=sc.nextInt();
        int m=sc.nextInt();
        Shared.processes=new int[n];
        for (int i=0;i<n;i++)
        {
            Shared.processes[i]=i;
        }

        Shared.avail=new int[m];
        for (int i=0;i<m;i++)
        {
            Shared.avail[i]=sc.nextInt();
        }

        Shared.allot=new int[n][m];
        for (int i=0;i<n;i++)
        {
            for (int j=0;j<m;j++)
            {
                Shared.allot[i][j]=sc.nextInt();
            }
        }

        Shared.maxm=new int[n][m];
        for (int i=0;i<n;i++)
        {
            for (int j=0;j<m;j++)
            {
                Shared.maxm[i][j]=sc.nextInt();
            }
        }
    }

    static class Process extends  Thread{
        int id;
        Semaphore sem;
        Process(int id, Semaphore sem)
        {
            this.id=id;
            this.sem=sem;
        }
        @Override
        public void run(){
            try {
            while (true)
            {

                sem.acquire();
                if (!Shared.canAssign(id))
                {
                    sem.release();

                }
                else
                {
                    Shared.assign(id);
                    sem.release();

                    break;
                }
            }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

    }
    static class Shared{

        static int processes[] ;
        static  int avail[] ;
        static int maxm[][] ;
        static int allot[][] ;

        static void needCalculator(int need[][], int maxReq[][],
                                   int allotedRes[][])
        {
            // Calculating Need of each P
            for (int i = 0 ; i < maxReq.length ; i++)
                for (int j = 0 ; j < maxReq[0].length ; j++)

                    // Need of instance = maxm instance -
                    //                 allocated instance
                    need[i][j] = maxReq[i][j] - allotedRes[i][j];
        }

        // Function to find the system is in safe state or not
        static boolean safeSeqPossible(int process[], int currAvail[], int maxReq[][],
                                       int currAllot[][])
        {
            int totalProcess=maxReq.length;
            int totalRes=maxReq[0].length;
            int [][]need = new int[maxReq.length][maxReq[0].length];

            // Function to calculate need matrix
            needCalculator(need, maxReq, currAllot);

            // Mark all processes as infinish
            boolean []isFinish = new boolean[totalProcess];
            for(int i=0; i<isFinish.length; i++)
                isFinish[i] = false;

            // Make a copy of available resources
            int []work = new int[totalRes];

            // To store safe sequence
            int []safeSeq = new int[totalProcess];

            for (int i = 0; i < totalRes ; i++)
                work[i] = currAvail[i];

            // While all processes are not finished
            // or system is not in safe state.
            int totalCount = 0;
            while (totalCount < totalProcess)
            {
                // Find a process which is not finish and
                // whose needs can be satisfied with current
                // work[] resources.
                boolean found = false;
                for (int p = 0; p < totalProcess; p++)
                {
                    // First check if a process is finished,
                    // if no, go for next condition
                    if (isFinish[p] == false)
                    {
                        // Check if for all resources of
                        // current P need is less
                        // than work
                        int j;
                        for (j = 0; j < totalRes; j++)
                            if (need[p][j] > work[j])
                                break;

                        // If all needs of p were satisfied.
                        if (j == totalRes)
                        {
                            // Add the allocated resources of
                            // current P to the available/work
                            // resources i.e.free the resources
                            for (int k = 0 ; k < totalRes ; k++)
                                work[k] += currAllot[p][k];

                            // Add this process to safe sequence.
                            safeSeq[totalCount] = p;
                            totalCount++;

                            // Mark this p as finished
                            isFinish[p] = true;

                            found = true;
                        }
                    }
                }

                // If we could not find a next process in safe
                // sequence.
                if (found == false)
                {
                    System.out.print("No Safe Sequence Found!");
                    return false;
                }
            }

            // If system is in safe state then
            // safe sequence will be as below
            System.out.print("Possible Safe Sequence Found:");
            for (int i = 0; i < totalProcess ; i++)
                System.out.print(safeSeq[i] + " ");

            return true;
        }

        static boolean canAssign(int process_id)
        {
            int P=maxm.length;
            int R=maxm[0].length;
            int [][]need = new int[maxm.length][maxm[0].length];

            // Function to calculate need matrix
            needCalculator(need, maxm, allot);

            int check=1;
            for (int i=0;i<R;i++)
            {
                if (need[process_id-1][i]>avail[i])
                    check=0;
            }
            if (check==1)
                return true;
            return false;
        }

        static boolean assign(int process_id)
        {
            int R=maxm[0].length;
            int [][]need = new int[maxm.length][maxm[0].length];

            // Function to calculate need matrix
            needCalculator(need, maxm, allot);
            if (!canAssign((process_id)))
                return false;
            System.out.println("-->Process "+process_id + ":");
            System.out.println("\tAllocated:\t"+Arrays.toString(allot[process_id-1]));
            System.out.println("\tNeeded:\t\t"+Arrays.toString(need[process_id-1]));
            System.out.println("\tAvailable:\t"+Arrays.toString(avail));
            System.out.println("\tResource Allocated!\t\t");
            System.out.println("\tProcess Running!\t\t");
            System.out.println("\tProcess Ended!\t\t");
            System.out.println("\tResources Released!\t\t");

            for (int i=0;i<R;i++)
            {
                avail[i]=avail[i]+allot[process_id-1][i];
                allot[process_id-1][i]=0;
                maxm[process_id-1][i]=0;
            }
            System.out.println("\tNow Available:\t"+Arrays.toString(avail));


            return true;
        }
    }

}

